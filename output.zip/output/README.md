To get the evaluation of our best model, please run the following:

$python eval.py

This will print the precision scores of the top 500 and bottom 500 deletion rates using the output of our best model: the GRU-based model trained on a combination of both Wikipedia and Twitter datasets.